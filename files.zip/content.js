// content.js – nasłuchuje wiadomości z popup i stosuje filtry CSS do wszystkich <video>

function applyFilters({ brightness, contrast }) {
  const videos = document.querySelectorAll("video");
  const filter = `brightness(${brightness}) contrast(${contrast})`;
  videos.forEach((v) => {
    v.style.filter = filter;
    v.style.webkitFilter = filter;
  });
}

function resetFilters() {
  const videos = document.querySelectorAll("video");
  videos.forEach((v) => {
    v.style.filter = "";
    v.style.webkitFilter = "";
  });
}

browser.runtime.onMessage.addListener((msg) => {
  if (msg.type === "APPLY_FILTERS") {
    applyFilters(msg.payload);
  } else if (msg.type === "RESET_FILTERS") {
    resetFilters();
  } else if (msg.type === "GET_VIDEO_COUNT") {
    return Promise.resolve({ count: document.querySelectorAll("video").length });
  }
});
