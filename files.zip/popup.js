// popup.js

const brightnessSlider = document.getElementById("brightness");
const contrastSlider   = document.getElementById("contrast");
const brightnessVal    = document.getElementById("brightnessVal");
const contrastVal      = document.getElementById("contrastVal");
const resetBtn         = document.getElementById("resetBtn");
const status           = document.getElementById("status");
const videoBadge       = document.getElementById("videoBadge");

// ── helpers ──────────────────────────────────────────────
function sliderToReal(v) {
  return (parseInt(v) / 100).toFixed(2);
}

function isDefault(sliderVal) {
  return parseInt(sliderVal) === 100;
}

function updateDisplay() {
  const b = sliderToReal(brightnessSlider.value);
  const c = sliderToReal(contrastSlider.value);

  brightnessVal.textContent = b + "×";
  contrastVal.textContent   = c + "×";

  brightnessVal.classList.toggle("changed", !isDefault(brightnessSlider.value));
  contrastVal.classList.toggle("changed",   !isDefault(contrastSlider.value));
}

function showStatus(msg, duration = 1800) {
  status.textContent = msg;
  status.classList.add("visible");
  clearTimeout(status._timer);
  status._timer = setTimeout(() => status.classList.remove("visible"), duration);
}

// ── send filters to content script ───────────────────────
function sendFilters() {
  const payload = {
    brightness: parseFloat(sliderToReal(brightnessSlider.value)),
    contrast:   parseFloat(sliderToReal(contrastSlider.value)),
  };

  browser.tabs.query({ active: true, currentWindow: true }).then(([tab]) => {
    if (!tab) return;
    browser.tabs.sendMessage(tab.id, { type: "APPLY_FILTERS", payload })
      .then(() => showStatus("zastosowano ✓"))
      .catch(() => showStatus("brak filmów na stronie"));
  });
}

function resetFilters() {
  brightnessSlider.value = 100;
  contrastSlider.value   = 100;
  updateDisplay();
  saveState();

  browser.tabs.query({ active: true, currentWindow: true }).then(([tab]) => {
    if (!tab) return;
    browser.tabs.sendMessage(tab.id, { type: "RESET_FILTERS" })
      .then(() => showStatus("zresetowano"))
      .catch(() => {});
  });
}

// ── persist state ─────────────────────────────────────────
function saveState() {
  browser.storage.local.set({
    brightness: brightnessSlider.value,
    contrast:   contrastSlider.value,
  });
}

function loadState() {
  browser.storage.local.get(["brightness", "contrast"]).then((data) => {
    if (data.brightness) brightnessSlider.value = data.brightness;
    if (data.contrast)   contrastSlider.value   = data.contrast;
    updateDisplay();
  });
}

// ── count videos on page ──────────────────────────────────
function fetchVideoCount() {
  browser.tabs.query({ active: true, currentWindow: true }).then(([tab]) => {
    if (!tab) return;
    browser.tabs.sendMessage(tab.id, { type: "GET_VIDEO_COUNT" })
      .then(({ count }) => {
        videoBadge.textContent = count + (count === 1 ? " film" : count < 5 ? " filmy" : " filmów");
        videoBadge.classList.toggle("has-videos", count > 0);
      })
      .catch(() => {
        videoBadge.textContent = "— filmów";
      });
  });
}

// ── events ───────────────────────────────────────────────
brightnessSlider.addEventListener("input", () => { updateDisplay(); sendFilters(); saveState(); });
contrastSlider.addEventListener("input",   () => { updateDisplay(); sendFilters(); saveState(); });
resetBtn.addEventListener("click", resetFilters);

// ── init ─────────────────────────────────────────────────
loadState();
fetchVideoCount();
